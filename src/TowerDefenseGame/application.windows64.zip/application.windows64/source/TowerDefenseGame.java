import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class TowerDefenseGame extends PApplet {

// Tower Defense Game | May 2021
// by Annika Damstedt


SoundFile startgame;
SoundFile tower;
SoundFile splash;
SoundFile enemydeath;
SoundFile laserSound; 
SoundFile lifelost;
SoundFile endgame;

PImage background;
PImage toxicdisplay;
PImage slowdisplay;
PImage bnwtoxicdisplay;
PImage bnwslowdisplay;
PImage towerimg;
PImage wolf, bear, fox;

ArrayList<Tower> towers;
ArrayList<Enemy> enemies;
ArrayList<Laser> lasers;
ArrayList<ToxicSplash> tsplashes;
ArrayList<SlowSplash> ssplashes;
ArrayList<Timer> lTimers;
Button[] buttons = new Button[12];
int money, lives, kills, spawn, ey;
Timer enemyTimer, enemyTimer2, enemyTimer3, tsplashTimer, ssplashTimer, tcooldown, scooldown;
boolean play;

public void setup() {
  
  
  endgame = new SoundFile (this, "gameover_sound.wav");
  startgame = new SoundFile (this, "gamestart.wav");
  splash = new SoundFile (this, "splash.wav");
  lifelost = new SoundFile (this, "lifelost.wav");
  tower = new SoundFile (this, "buildtower.wav");
  laserSound = new SoundFile (this, "laser.wav");
  enemydeath = new SoundFile (this, "monsterdeath1.wav");
  
  background = loadImage ("tdbackground.png");
  toxicdisplay = loadImage ("toxicdisplay.png");
  slowdisplay = loadImage ("slowdisplay.png");
  bnwtoxicdisplay = loadImage ("bnwtoxicdisplay.png");
  bnwslowdisplay = loadImage ("bnwslowdisplay.png");

  // buttons
  buttons [0] = new Button (50, 15, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [1] = new Button (350, 15, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [2] = new Button (50, 313, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [3] = new Button (300, 313, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [4] = new Button (50, 610, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [5] = new Button (350, 610, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [6] = new Button (650, 150, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [7] = new Button (825, 150, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [8] = new Button (1000, 150, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [9] = new Button (650, 475, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [10] = new Button (825, 475, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);
  buttons [11] = new Button (1000, 475, 125, 125, "Open plot", 0xffE88D31, 0xffA05403);

  // set up variables
  towers = new ArrayList();
  enemies = new ArrayList();
  lasers = new ArrayList();
  tsplashes = new ArrayList();
  ssplashes = new ArrayList();
  lTimers = new ArrayList();

  money = 600;
  lives = 10;
  kills = 0;

  enemyTimer = new Timer (4000);
  enemyTimer.start();
  enemyTimer2 = new Timer (2000);
  enemyTimer2.start();
  enemyTimer3 = new Timer (1000);
  enemyTimer3.start();
  ssplashTimer = new Timer (10000);
  ssplashTimer.start();
  tsplashTimer = new Timer (10000);
  tsplashTimer.start();
  tcooldown = new Timer (2000);
  scooldown = new Timer (2000);
}

public void draw() {
  if (!play) {
    startScreen();
  } else {
    image (background, 0, 0);
    
    fill (0);
    textSize (24);
    text (lives, 775, 710);
    text (money, 950, 710);
    text (kills, 1125, 710);

    //call buttons
    for (int i=0; i<buttons.length; i++) {
      buttons[i].display();
      buttons[i].hover();
    }
    
    // display abilities
    if (ssplashTimer.isFinished()) {
      image (slowdisplay, 975, 20);  
    } else if (!ssplashTimer.isFinished()) {
      image (bnwslowdisplay, 975, 20);
    }
    if (tsplashTimer.isFinished()) {
      image (toxicdisplay, 1080, 20);
    } else if (!tsplashTimer.isFinished()) {
      image (bnwtoxicdisplay, 1080, 20);
    }

    // use slow splash
    if (ssplashTimer.isFinished() && keyPressed && key == '1') {
      ssplashes.add(new SlowSplash(mouseX, mouseY));
      splash.play();
      ssplashTimer.start();
      scooldown.start();
    }

    for (int i=0; i<ssplashes.size(); i++) {
      SlowSplash ssplash = ssplashes.get(i);
      ssplash.display();
      for (int j=0; j<enemies.size(); j++) {
        Enemy enemy = enemies.get(j);
        if (enemy.ssplashIntersection(ssplash)) {
          enemy.speed = 1;
        }
        if (scooldown.isFinished()) {
          enemy.speed = enemy.cSpeed;
          ssplashes.remove(ssplash);
        }
      }
    }

    // use toxic splash
    if (tsplashTimer.isFinished() && keyPressed && key == '2') {
      tsplashes.add(new ToxicSplash(mouseX, mouseY));
      splash.play();
      tsplashTimer.start();
      tcooldown.start();
    }

    for (int i=0; i<tsplashes.size(); i++) {
      ToxicSplash tsplash = tsplashes.get(i);
      tsplash.display();
      for (int j=0; j<enemies.size(); j++) {
        Enemy enemy = enemies.get(j);
        if (enemy.tsplashIntersection(tsplash)) {
          enemy.health-=2;
        }
      }
      if (tcooldown.isFinished()) {
        tsplashes.remove(tsplash);
      }
    }

    // switch enemy spawn
    spawn = PApplet.parseInt (random (2));
    switch (spawn) {
    case 0:
      ey = 225;
      break;
    case 1:
      ey = 525;
      break;
    }

    // enemy timer
    if (enemyTimer.isFinished() && kills <= 10) {
      enemies.add(new Enemy(-50, ey));
      enemyTimer.start();
    }

    // enemy timer 2
    if (enemyTimer2.isFinished() && kills > 10 && kills <= 30) {
      enemies.add(new Enemy(-50, ey));
      enemyTimer2.start();
    }

    // enemy timer 3
    if (enemyTimer3.isFinished() && kills >30) {
      enemies.add(new Enemy(-50, ey));
      enemyTimer3.start();
    }

    // add enemies
    for (int i = 0; i < enemies.size(); i++) {
      Enemy enemy = enemies.get(i);
      enemy.display();
      enemy.move();
      if (enemy.reachedEnd()) {
        enemies.remove(enemy);
        lives--;
        lifelost.play();
      }
    }

    // add towers + laser timer
    for (int i=0; i<towers.size(); i++) {
      Tower tower = towers.get(i);
      tower.display();
      for (int j=0; j<lTimers.size(); j++) {
        Timer lTimer = lTimers.get(i);
        if (lTimer.isFinished()) {
          lasers.add (new Laser (tower.x+63, tower.y+63));
          laserSound.play();
          lTimer.start();
        }
      }
    }

    // add lasers
    for (int i=0; i<lasers.size(); i++) {
      Laser laser = lasers.get(i);
      laser.display();
      laser.move();
      if (laser.reachedEnd()) {
        lasers.remove(laser);
      }
      for (int j=0; j<enemies.size(); j++) {
        Enemy enemy = enemies.get(j);
        if (enemy.laserIntersection(laser)) {
          enemy.health -= laser.damage;
          lasers.remove(laser);
        }
      }
    }

    for (int i=0; i<enemies.size(); i++) {
      Enemy enemy = enemies.get(i);
      if (enemy.health < 10) {
        if (enemy.type == 0) {
          money += 100;
        } else if (enemy.type == 1) {
          money += 150;
        } else if (enemy.type == 2) {
          money += 50;
        }
        enemies.remove(enemy);
        enemydeath.play();
        kills++;
      }
    }

    // end condition
    if (lives == 0) {
      play = false;
      endgame.play();
      gameOver();
    }
  }
}

public void mousePressed() {
  for (int i=0; i<buttons.length; i++) {
    if (buttons[i].hover && money >= 300) {
      towers.add(new Tower(buttons[i].x, buttons[i].y));
      tower.play();
      lTimers.add(new Timer(1000));
      money -= 300;
      buttons[i].used = true;
    }
  }
}

public void infoPanel() {
  background (230);
  fill (0);
  textSize (50);
  textAlign (LEFT);
  text ("Info Panel", 20, 50);
  textSize (35);
  text ("Tower", 20, 100);
  text ("Enemies", 20, 325);
  text ("Abilities", 20, 550);
  textSize (25);
  text ("Click a button to place a tower. $300 is required. It will shoot bullets along the path, killing enemies.", 225, 135, 500, 200);
  text ("The wolf has a normal speed and health. The bear has a slow speed and high health. The fox has high speed and low health.", 550, 360, 550, 200);
  text ("Click '1' and where your mouse is an ice spill will temporarily slow enemies.", 400, 585, 600, 200);
  text ("Click '2' and where your mouse is a toxic spill will temporarily damage enemies.", 400, 660, 600, 200);
  // tower display
  towerimg = loadImage ("tower.png");
  image (towerimg, 20, 100, 200, 200);
  // enemies display
  wolf = loadImage ("wolf1.png");
  image (wolf, 30, 375, 140, 100); 
  bear = loadImage ("bear1.png");
  image (bear, 190, 375, 200, 120);
  fox = loadImage ("fox1.png");
  image (fox, 375, 375, 160, 80);
  // abilities display
  image (slowdisplay, 50, 600, 112, 150);
  image (toxicdisplay, 212, 600, 112, 150);
}

public void startScreen() {
  background (0xff64D386);
  textSize (50);
  textAlign (CENTER);
  fill (0);
  text ("Tower Defense Game", width/2, height/2);
  textSize (40);
  text ("Click anywhere to play", width/2, height/2+40);
  textSize (20);
  text ("Press 'i' to see information about the game", 220, height-30);

  if (keyPressed && key == 'i') {
    infoPanel();
  }

  if (mousePressed) {
    play = true;
    startgame.play();
  }
}

public void gameOver() {
  background(0xff123B1F);
  textAlign (CENTER);
  fill (222);
  textSize (20);
  text ("You died!", width/2, height/2);
  text("You killed " + kills + " enemies!", width/2, height/2+40);
  noLoop();
}
class Button {
  // Member variables
  int x, y, w, h;
  int c1, c2;
  String text;
  boolean hover, used;

  // Constructor
  Button(int tempX, int tempY, int tempW, int tempH, String tempText, int tempc1, int tempc2) {
    x = tempX;
    y = tempY;
    w = tempW;
    h = tempH;
    c1 = tempc1;
    c2 = tempc2;
    text = tempText;
    hover = false;
    used = false;
  }

  // Display Method
  public void display() {
    if (used == false) {
      if (hover) {
        fill (c2);
      } else {
        fill (c1);
      }

      rect (x, y, w, h, 7);

      strokeWeight (4);
      stroke (0, 100);
      line (x+2, y+h-2, x+w-2, y+h-2);
      line (x+w-2, y+h-2, x+w-2, y+2);

      stroke (255, 100);
      line (x+2, y+h-2, x+2, y+2);
      line (x+2, y+2, x+w-2, y+2);

      strokeWeight (1);

      fill (0);
      textAlign (CENTER);
      textSize (14);
      text (text, x+w/2-1, y+h/2+3);
    }
  }

  // Hover Method
  public void hover() {
    if (used == true) {
      hover = false;
    } else {
      hover = (mouseX>x && mouseX<x+w && mouseY>y && mouseY<y+h);
    }
  }
}
class Enemy {
  // member variables
  int x, y, speed, health, r, type, cSpeed;
  PImage fox1, fox2, wolf1, wolf2, bear1, bear2;

  // constructor
  Enemy(int x, int y) {
    this.x = x;
    this.y = y;
    type = PApplet.parseInt (random (3));
    switch (type) {
    case 0: // normal
      speed = 3;
      cSpeed = 3;
      health = 400;
      r = 50;
      break;
    case 1: // slow high
      speed = 1;
      cSpeed = 1;
      health = 800;
      r = 60;
      break;
    case 2: // high low
      speed = 5;
      cSpeed = 5;
      health = 200;
      r = 40;
      break;
    }
  }

  // member methods
  public boolean ssplashIntersection(SlowSplash ssplash) {
    float distance = dist (x, y, ssplash.x, ssplash.y);
    if (distance < r + ssplash.r - 50) {
      return true;
    } else {
      return false;
    }
  }

  public boolean tsplashIntersection(ToxicSplash tsplash) {
    float distance = dist (x, y, tsplash.x, tsplash.y);
    if (distance < r + tsplash.r - 50) {
      return true;
    } else {
      return false;
    }
  }

  public boolean laserIntersection(Laser laser) {
    float distance = dist (x, y, laser.x, laser.y);
    if (distance < r + laser.r) {
      return true;
    } else {
      return false;
    }
  }

  public boolean reachedEnd() {
    if (x > width + 50) {
      return true;
    } else {
      return false;
    }
  }

  public void move() {
    if (x < 550) {
      x += speed;
    } 
    if (x > 545 && x < 550) {
      x = 550;
    }
    if (x == 550) {
      if (y < 375) {
        y += speed;
      } else if (y > 375) {
        y -= speed;
      }
    } 
    if (y == 375) {
      x += speed;
    }
  }

  public void display() {
    frameRate(60);
    switch (type) {
    case 0: // normal
      wolf1 = loadImage ("wolf1.png");
      wolf2 = loadImage ("wolf2.png");
      if (frameCount % 100 < 50) {
        image (wolf1, x-35, y-25);
      } else {
        image (wolf2, x-35, y-25);
      }
      break;
    case 1: // slow high
      bear1 = loadImage ("bear1.png");
      bear2 = loadImage ("bear2.png");
      if (frameCount % 100 < 50) {
        image (bear1, x-50, y-30);
      } else {
        image (bear2, x-50, y-30);
      }
      break;
    case 2: // high low
      fox1 = loadImage ("fox1.png");
      fox2 = loadImage ("fox2.png");
      if (frameCount  % 10 < 5) {
        image (fox1, x-40, y-20, 80, 40);
      } else {
        image (fox2, x-40, y-20, 80, 40);
      }
      break;
    }
  }
}
class Laser {
  // member variables
  int x, y, a, speed, damage, r, type, radius;
  PImage arrow, arrow1;

  // constructor
  Laser(int x, int y) {
    this.x = x;
    this.y = y;
    r = 7;
    speed = 5;
    damage = 200;
    a = y;
  }

  // member methods
  public void move() { 
    if (a > 375) {
      y -= speed;
    } else if (a < 375) {
      y += speed;
    }
  }

  public boolean reachedEnd() {
    if (y < -50 || y > 800) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    arrow = loadImage ("arrow.png");
    arrow1 = loadImage ("arrow1.png");
    if (a > 375) {
      image (arrow, x, y);
    } else if (a < 375) {
      image (arrow1, x, y);
    }
  }
}
class SlowSplash {
  // member variables
  int x, y, r;
  PImage slowsplash;
  
  // constructor
  SlowSplash(int x, int y) {
    this.x = x;
    this.y = y;
    r = 100;
  }
  
  // member methods  
  public void display() {
    slowsplash = loadImage ("slowsplash.png");
    image (slowsplash, x-50, y-50);
  }
}
// Example 10-5: Object-oriented timer
// by Daniel Shiffman

class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
class Tower {
  // member variables
  int x, y;
  PImage tower, tower1;

  // constructor
  Tower(int x, int y) {
    this.x = x;
    this.y = y;
  }

  // member methods
  public void display() {
    tower = loadImage ("tower.png");
    tower1 = loadImage ("tower1.png");
    if (y > 375) {
      image (tower, x, y);
    } else if (y < 375) {
      image (tower1, x, y);
    }
  }
}
class ToxicSplash {
  // member variables
  int x, y, r;
  PImage toxicsplash;
  
  // constructor
  ToxicSplash(int x, int y) {
    this.x = x;
    this.y = y;
    r = 100;
  }
  
  // member methods  
  public void display() {
    toxicsplash = loadImage ("toxicsplash.png");
    image (toxicsplash, x-50, y-50);
  }
}
  public void settings() {  size (1200, 750); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "TowerDefenseGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
